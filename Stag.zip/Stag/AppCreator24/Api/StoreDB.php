<?php

  require 'con.php';
  include 'error.php';
  
  function storeData($AppId, $Url){
  try{
      $query="INSERT INTO `appcreator24`(`app_id`, `url`) VALUES ('$AppId','$Url')";
      $insertData=mysqli_query($GLOBALS['con'],$query);
     }catch(Exception $e) {
        wh_log('Message: ' .$e->getMessage());
        return 'Message: ' .$e->getMessage();
    }
  }
?>