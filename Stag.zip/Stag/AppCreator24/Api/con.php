<?php

	$con=mysqli_connect("localhost","root","","appcreator24");
	// Check connection
	if($con){
		echo " Successssssssssssss";
	}
?>



