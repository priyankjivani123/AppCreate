<?php

 include 'Header.php';
 include 'Session.php';
 include 'Api/StoreDB.php';
  
      $headers=array('Host: www.appcreator24.com','Connection: keep-alive','Content-Length: '.strlen($dataa).'','sec-ch-ua: "Chromium";v="110", "Not A(Brand";v="24", "Google Chrome";v="110"','Accept: */*','Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryGqSFtCdKdcPkwoi2','X-Requested-With: XMLHttpRequest','sec-ch-ua-mobile: ?1','User-Agent: Mozilla/5.0 (Linux; Android 10; Redmi Note 7 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Mobile Safari/537.36','sec-ch-ua-platform: "Android"','Origin: https://www.appcreator24.com','Sec-Fetch-Site: same-origin','Sec-Fetch-Mode: cors','Sec-Fetch-Dest: empty','Referer: https://www.appcreator24.com/intra/intra.php?idioma=en&idsesion='.$idSession.'&pag=21&idapp=1435617','Accept-Encoding: gzip, deflate, br','Accept-Language: en-IN,en-GB;q=0.9,en-US;q=0.8,en;q=0.7,hi;q=0.6','Cookie: acdisp='.$acDisp.'; idcookie='.$idCookie.'');
    
      try{  
               $name="";
               $Link='';
               $dataaaa= str_replace($oldLink,$Link,$data);
               $dataa= str_replace($oldName,$name,$dataaaa);
               $responseHeaders=HttpCall($url,$dataa,$headers,"POST",0);
               preg_match('/ID:(\d+)-/', $responseHeaders, $matches);
               $id = $matches[1];
               echo storeData($id,$url);
         }catch(Exception $e) {
                wh_log('Message: ' .$e->getMessage());
                return 'Message: ' .$e->getMessage();
        }
    
    
        ?>
