<?php
$idSession="qmvnhal79x4ctz8o5sjkfyb1uw26dirpg3e0";
$idCookie="w71ulsobvnmpkice25jahqr34fdtgxz8y906%40887931%400";
$acDisp="h5v0nbagw3yuloq";
$data=file_get_contents('1678367140949.txt');
$url="https://www.appcreator24.com/intra/app_sec_video_guardando.php?idioma=en&idsesion=".$idSession."&idapp=1435617&idsec=";
$oldLink="https://prod-fastly-ap-northeast-2.video.pscp.tv/Transcoding/v1/hls/1VOKv9D62qksYTOxCYR2q7dBdb1z8-oAI18PcsWuy24v92bWOIN_EUHR9T8TxJbR_1Prp-gQzIa6i09igwYtOQ/non_transcode/us-west-2/periscope-replay-direct-live/st_master_dynamic_highlatency.m3u8?type=live";
$oldName="Star Sports 1 Hindi";
         
?>